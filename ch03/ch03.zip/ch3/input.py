first = input('Enter your first name: ')
last = input('Enter your last name: ')
line1 = 'Hello '+ first + ' ' + last + '...'
line2 = 'Welcome to the world of Python!'
print(line1)
print(line2)
