temp = eval(input('Enter the current temperature: '))

if temp > 86:
    print("It's hot!")
    print('Be sure to drink liquids.')

print('Goodbye.')
