phrase = input('Enter a phrase: ')

for c in phrase:
  if c in 'aeiouAEIOU':
    print(c)
