# a really small module
a = 0
