import three

def f2():
    three.f3()
