import two

def f1():
    two.f2()

def f4():
    print('Hello!')
