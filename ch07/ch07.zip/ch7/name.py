print('My name is {}'.format(__name__))
