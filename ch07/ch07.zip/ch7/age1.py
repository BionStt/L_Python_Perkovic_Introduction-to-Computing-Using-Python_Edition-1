strAge = input('Enter your age: ')
intAge = int(strAge)
print('You are {} years old.'.format(intAge))
