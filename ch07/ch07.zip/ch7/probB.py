def g(x):
    print(f(x))

def f(x):
    return 2*x+1

g(3)
